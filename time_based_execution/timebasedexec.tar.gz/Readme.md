#Time Based Execution.
This project basically reads the info provided in the csv file and perform the operation accordinly if current time of a country matches the provided time range and day.

#Dependency installation:

Command: 
1. python3 -m venv venv
2. source venv/bin/activate
3. pip3 install -r requirement.txt

##How to run
Command:

python run.py < absolute_config.csv_file_path >
